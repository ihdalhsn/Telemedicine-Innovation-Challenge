class Reader {
  static const int ANALOG_PIN;
  
private:
  int process(int read);

public:
  int read();
} ;

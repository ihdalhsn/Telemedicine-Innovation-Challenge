# TA-Sensor
Project sensor TA.

NodeMCU 1.0, ESP8266.

Platform.io IDE and Framework